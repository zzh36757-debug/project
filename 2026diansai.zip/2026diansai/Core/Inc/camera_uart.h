#ifndef __CAMERA_UART_H
#define __CAMERA_UART_H

#include <stdint.h>
#include <stdbool.h>

/**
 * @brief  初始化摄像头 UART 接收，开始监听数据
 * @note   调用后会自动通过中断逐字节接收，用户无需再操作
 */
void Camera_UART_Init(void);

/**
 * @brief  获取最新的 X 坐标值
 * @retval 摄像头返回的 X 值（单位：像素）
 * @note   如果还没收到过数据，返回 0；收到新数据后自动更新
 */
int32_t Camera_GetX(void);

/**
 * @brief  获取最新的小球速度值
 * @retval 摄像头返回的速度值（带符号：正=往右，负=往左）
 * @note   如果还没收到过数据，返回 0
 */
int32_t Camera_GetV(void);

/**
 * @brief  检查是否有新数据到达
 * @retval true=有新的 (X, V) 数据，false=没有
 * @note   读取后标志自动清除
 */
bool Camera_NewDataAvailable(void);

/*==================================================================
 *  串口调参命令 API（USART1 RX）
 *==================================================================*/

/**
 * @brief  检查是否有新的调参命令到达
 * @retval true=有新命令，false=没有
 * @note   读取后标志自动清除；用 GetTarget/GetKp/GetKd 取具体值
 */
bool SerialCmd_NewCommand(void);

/**
 * @brief  获取命令里的目标 X 坐标
 * @retval 目标值（像素），若没收到过命令则返回默认值
 */
int32_t SerialCmd_GetTarget(void);

/**
 * @brief  获取命令里的 Kp 值
 * @retval Kp（浮点），若没收到过命令则返回默认值
 */
float SerialCmd_GetKp(void);

/**
 * @brief  获取命令里的 Kd 值
 * @retval Kd（浮点），若没收到过命令则返回默认值
 */
float SerialCmd_GetKd(void);

#endif /* __CAMERA_UART_H__ */
