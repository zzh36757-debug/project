#ifndef __TASK_MOTOR_H
#define __TASK_MOTOR_H

#ifdef __cplusplus
extern "C" {
#endif

void Task_Motor_Run(void *argument);

#ifdef __cplusplus
}
#endif

#endif /* __TASK_MOTOR_H */
