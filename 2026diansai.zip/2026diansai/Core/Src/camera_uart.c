#include "camera_uart.h"
#include "usart.h"
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <stdbool.h>

/*==================================================================
 *  摄像头 USART2 接收
 *==================================================================*/
#define CAM_RX_BUF_SIZE  64

static uint8_t  cam_rx_buf[CAM_RX_BUF_SIZE];
static uint8_t  cam_rx_index = 0;
static uint8_t  cam_rx_byte;

static int32_t  cam_x = 0;
static int32_t  cam_v = 0;
static volatile bool cam_new_data = false;

static void Camera_StartRx(void)
{
    HAL_UART_Receive_IT(&huart2, &cam_rx_byte, 1);
}

static void Camera_ParseLine(uint8_t *line, uint8_t len)
{
    if (len < 4) return;

    if (line[0] != '%' || line[1] != 'r') return;

    uint8_t pos = 2;

    /* ---- 解析 X 坐标 ---- */
    char str_x[16] = {0};
    uint8_t nx = 0;
    while (pos < len && nx < 15)
    {
        char c = (char)line[pos];
        if ((c >= '0' && c <= '9') || c == '-' || c == '+')
        {
            str_x[nx++] = c;
            pos++;
        }
        else if (c == ' ')
        {
            pos++;
            break;
        }
        else
        {
            return;
        }
    }
    str_x[nx] = '\0';
    if (nx == 0) return;

    /* ---- 解析速度 V ---- */
    char str_v[16] = {0};
    uint8_t nv = 0;
    while (pos < len && nv < 15)
    {
        char c = (char)line[pos];
        if ((c >= '0' && c <= '9') || c == '-' || c == '+')
        {
            str_v[nv++] = c;
            pos++;
        }
        else if (c == '\r' || c == '\n')
        {
            break;
        }
        else
        {
            return;
        }
    }
    str_v[nv] = '\0';
    if (nv == 0) return;

    cam_x = (int32_t)atoi(str_x);
    cam_v = (int32_t)atoi(str_v);
    cam_new_data = true;

    /* TX 已移到 task_motor.c 的任务上下文里发送，不在 ISR 里阻塞 */
}

/*==================================================================
 *  串口调参 USART1 RX — 解析 "target,kp,kd\n" 格式
 *==================================================================*/
#define CMD_RX_BUF_SIZE  64

static uint8_t  cmd_rx_buf[CMD_RX_BUF_SIZE];
static uint8_t  cmd_rx_index = 0;
static uint8_t  cmd_rx_byte;

static int32_t  cmd_target = 170;       /* 默认目标值 */
static float    cmd_kp     = 0.9f;      /* 默认 Kp */
static float    cmd_kd     = 8.8f;      /* 默认 Kd */
static volatile bool cmd_new = false;

static void SerialCmd_StartRx(void)
{
    HAL_UART_Receive_IT(&huart1, &cmd_rx_byte, 1);
}

/**
 * @brief  解析一行 "170,0.9,8.8" → target, kp, kd
 */
static void SerialCmd_ParseLine(uint8_t *line, uint8_t len)
{
    if (len < 5) return;   /* 至少 "1,1,1" */

    /* ---- 跳过前导空白 ---- */
    uint8_t pos = 0;
    while (pos < len && (line[pos] == ' ' || line[pos] == '\t')) pos++;
    if (pos >= len) return;

    /* ---- 复制到可修改 buffer（strtok 会破坏原串） ---- */
    char tmp[CMD_RX_BUF_SIZE];
    uint8_t n = 0;
    while (pos < len && n < CMD_RX_BUF_SIZE - 1 && line[pos] != '\r' && line[pos] != '\n')
    {
        tmp[n++] = (char)line[pos++];
    }
    tmp[n] = '\0';
    if (n == 0) return;

    /* ---- 按逗号切分 ---- */
    char *tok1 = strtok(tmp, ",");
    if (!tok1) return;
    char *tok2 = strtok(NULL, ",");
    if (!tok2) return;
    char *tok3 = strtok(NULL, ",");
    if (!tok3) return;

    /* ---- 转换并保存（临界区：关中断保证原子写入） ---- */
    int32_t t = (int32_t)atoi(tok1);
    float   p = (float)atof(tok2);
    float   d = (float)atof(tok3);

    __disable_irq();
    cmd_target = t;
    cmd_kp    = p;
    cmd_kd    = d;
    cmd_new   = true;
    __enable_irq();
}

/*==================================================================
 *  HAL UART 回调 — 统一入口，按 UART 实例分发
 *==================================================================*/
void HAL_UART_RxCpltCallback(UART_HandleTypeDef *huart)
{
    if (huart->Instance == USART2)
    {
        /* ---- 摄像头数据 ---- */
        uint8_t ch = cam_rx_byte;

        if (ch == '\n')
        {
            Camera_ParseLine(cam_rx_buf, cam_rx_index);
            cam_rx_index = 0;
        }
        else if (ch != '\r' && cam_rx_index < CAM_RX_BUF_SIZE - 1)
        {
            cam_rx_buf[cam_rx_index++] = ch;
        }

        Camera_StartRx();
    }
    else if (huart->Instance == USART1)
    {
        /* ---- 串口调参命令 ---- */
        uint8_t ch = cmd_rx_byte;

        if (ch == '\n')
        {
            cmd_rx_buf[cmd_rx_index] = '\0';
            USART_ParseTask((const char *)cmd_rx_buf);
            SerialCmd_ParseLine(cmd_rx_buf, cmd_rx_index);
            cmd_rx_index = 0;
        }
        else if (ch != '\r' && cmd_rx_index < CMD_RX_BUF_SIZE - 1)
        {
            cmd_rx_buf[cmd_rx_index++] = ch;
        }

        SerialCmd_StartRx();
    }
}

/*==================================================================
 *  公开 API
 *==================================================================*/

/** 摄像头数据 */

int32_t Camera_GetX(void)
{
    return cam_x;
}

int32_t Camera_GetV(void)
{
    return cam_v;
}

bool Camera_NewDataAvailable(void)
{
    if (cam_new_data)
    {
        cam_new_data = false;
        return true;
    }
    return false;
}

void Camera_UART_Init(void)
{
    cam_rx_index = 0;
    cam_x = 0;
    cam_v = 0;
    cam_new_data = false;

    /* 启动 USART2 摄像头接收 */
    Camera_StartRx();

    /* 启动 USART1 串口命令接收 */
    cmd_rx_index = 0;
    SerialCmd_StartRx();
}

/** 串口调参命令 */

bool SerialCmd_NewCommand(void)
{
    if (cmd_new)
    {
        cmd_new = false;
        return true;
    }
    return false;
}

int32_t SerialCmd_GetTarget(void)
{
    return cmd_target;
}

float SerialCmd_GetKp(void)
{
    return cmd_kp;
}

float SerialCmd_GetKd(void)
{
    return cmd_kd;
}
