/**
 ******************************************************************************
 * @file    task_motor.c
 * @brief   水管钢珠水平平衡 — KP×位置偏差 − KD×速度
 *          摄像头已做滤波，STM32 直接使用 X 和 V
 *          支持串口在线调参：USART1 收 "target,kp,kd" 格式命令
 *          支持任务切换：USART1 收 "task:N" 切换任务
 ******************************************************************************
 */

#include "task_motor.h"
#include "cmsis_os.h"
#include "main.h"
#include "Emm_V5.h"
#include "camera_uart.h"
#include "usart.h"
#include <stdio.h>
#include <stdlib.h>

typedef enum {
    task0,
    task1,
    task2,
    task3,
} task_num;

task_num my_task = task2;

/*==================================================================
 *  可调参数（可通过串口在线修改）
 *==================================================================*/
static int32_t  target_x   = 223;       /* 目标 X 坐标（小球平衡中心点） */
static float    kp         = 1.6f;      /* 位置比例：偏差越大，往回拉的力越大 */
static float    kd         = 8.8f;      /* 速度阻尼：速度越快，刹车越狠 */
static int32_t  target_task_x  = 158;       /* 目标 X 坐标（小球平衡中心点） */
static float    kp2         = 1.6f;      /* 位置比例：偏差越大，往回拉的力越大 */
static float    kd2         = 8.8f;      /* 速度阻尼：速度越快，刹车越狠 */

/*==================================================================
 *  固定参数
 *==================================================================*/
#define DEAD_ZONE       0               /* 死区（像素）：偏差在此范围内不动作 */
#define DEAD_ZONE2       5               /* 死区（像素）：偏差在此范围内不动作 */
#define MAX_DELTA       80              /* 单次位置增量上限，防止突变 */
#define POS_VEL         400             /* 电机运动速度（RPM） */
#define POS_ACC         400             /* 电机加速度 */

extern UART_HandleTypeDef huart1;

/*==================================================================
 *  Task_Motor_Run — 电机控制任务
 *==================================================================*/
void Task_Motor_Run(void *argument)
{
    /* ---- 上电延时，等电机初始化 ---- */
    osDelay(1000);

    /* ---- 电机回零（单圈就近回零） ---- */
    Emm_V5_Origin_Trigger_Return(1, 0, false);
    osDelay(500);

    /* ---- 控制变量 ---- */
    int32_t camera_x   = 0;      /* 摄像头：小球 X 坐标（像素） */
    int32_t camera_v   = 0;      /* 摄像头：小球速度（带符号，正=往右，负=往左） */
    int32_t error      = 0;      /* 位置偏差 = 目标 − 实际 */
    int32_t motor_out  = 0;      /* 控制输出（脉冲），直接作为电机位置 */

    for(;;)
    {
        /* ---- 检查串口任务切换命令 ---- */
        int8_t cmd = USART_GetTask();

        switch(my_task)
        {
        case task0:
        {
        }
        break;

        case task1:
        {
            /* ---- 等摄像头来新数据 ---- */
            if (Camera_NewDataAvailable())
            {
                camera_x = Camera_GetX();
                camera_v = -Camera_GetV();

                error = target_x - camera_x;

                /* ---- 死区 ---- */
                if (error > -DEAD_ZONE && error < DEAD_ZONE)
                {
                    continue;
                }

                if (target_x >= 155)
                {
                    kp = 2.0f;
                    kd = 8.8f;
                }
                else
                {
                    kp = 1.45f;
                    kd = 8.8f;
                }

                motor_out = (int32_t)(kp * error - kd * camera_v);

                /* ---- 位置限幅 ---- */
                if      (motor_out >  MAX_DELTA) motor_out =  MAX_DELTA;
                else if (motor_out < -MAX_DELTA) motor_out = -MAX_DELTA;

                /* ---- 直接作为位置发出去，不累加 ---- */
                uint8_t  dir = (motor_out >= 0) ? 1 : 0;
                uint32_t clk = (uint32_t)(motor_out >= 0 ? motor_out : -motor_out);
                Emm_V5_Pos_Control(1, dir, POS_VEL, POS_ACC, clk, 1, false);

                /* ---- 通过 USART1 上报数据到 VoFA 上位机 ---- */
                char tx_buf[64];
                int tx_len = sprintf(tx_buf, "%ld,%ld,%d,%.2f,%.2f,%d\r\n",
                                     (long)target_x,
                                     (long)camera_x,
                                     dir,
                                     (double)kp,
                                     (double)kd,
                                     (int)clk);
                HAL_UART_Transmit(&huart1, (uint8_t *)tx_buf, tx_len, 100);

                if (abs(camera_x - target_x) <= 5)
                {
                    target_x = 99;
                }
            }
           
        }
        break;

        case task2:
        {
            /* ---- 等摄像头来新数据 ---- */
            if (Camera_NewDataAvailable())
            {
                camera_x = Camera_GetX();
                camera_v = -Camera_GetV();

                error = target_task_x - camera_x;

                /* ---- 死区 ---- */
                if (error > -DEAD_ZONE2 && error < DEAD_ZONE2)
                {
                    continue;
                }

                motor_out = (int32_t)(kp2 * error - kd2 * camera_v);

                /* ---- 位置限幅 ---- */
                if      (motor_out >  MAX_DELTA) motor_out =  MAX_DELTA;
                else if (motor_out < -MAX_DELTA) motor_out = -MAX_DELTA;

                /* ---- 直接作为位置发出去，不累加 ---- */
                uint8_t  dir = (motor_out >= 0) ? 1 : 0;
                uint32_t clk = (uint32_t)(motor_out >= 0 ? motor_out : -motor_out);
                Emm_V5_Pos_Control(1, dir, POS_VEL, POS_ACC, clk, 1, false);

                /* ---- 通过 USART1 上报数据到 VoFA 上位机 ---- */
                char tx_buf[64];
                int tx_len = sprintf(tx_buf, "%ld,%ld,%d,%.2f,%.2f,%d\r\n",
                                     (long)target_task_x,
                                     (long)camera_x,
                                     dir,
                                     (double)kp,
                                     (double)kd,
                                     (int)clk);
                HAL_UART_Transmit(&huart1, (uint8_t *)tx_buf, tx_len, 100);

            }
           
        }
        break;

        case task3:
        {
        }
        break;
        }
		 osDelay(9);
    }
}
