2026diansai\syscalls.o: ..\Core\Src\syscalls.c
2026diansai\syscalls.o: D:\keil5\ARM\ARMCC\Bin\..\include\stddef.h
2026diansai\syscalls.o: D:\keil5\ARM\ARMCC\Bin\..\include\errno.h
2026diansai\syscalls.o: D:\keil5\ARM\ARMCC\Bin\..\include\stdio.h
2026diansai\syscalls.o: D:\keil5\ARM\ARMCC\Bin\..\include\time.h
