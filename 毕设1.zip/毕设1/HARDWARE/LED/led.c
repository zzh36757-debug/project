#include "led.h"
#include "delay.h"

void LED_Init(void)
{
	//����GPIOBʱ��
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOC, ENABLE);
	
	//����LED����Ϊģ�����ģʽ
	GPIO_InitTypeDef GPIO_InitStructure;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;
	GPIO_InitStructure.GPIO_Pin = LED_GPIO_PIN;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(LED_GPIO_PROT, &GPIO_InitStructure);
	GPIO_ResetBits(LED_GPIO_PROT, LED_GPIO_PIN);
}

void LED_Toggle(void)
{
	GPIO_WriteBit(LED_GPIO_PROT, LED_GPIO_PIN, (BitAction)((1-GPIO_ReadOutputDataBit(LED_GPIO_PROT, LED_GPIO_PIN))));//led��ƽ��ת
}
void LED_On()
{
	GPIO_WriteBit(LED_GPIO_PROT, LED_GPIO_PIN,(BitAction)0);
}
void LED_Off()
{
	GPIO_WriteBit(LED_GPIO_PROT, LED_GPIO_PIN,(BitAction)1);
}

void LED_Twinkle()
{
	LED_On();
	delay_ms(10);
	LED_Off();
}

void Box1_Green(void)
{
    GPIO_ResetBits(GPIOA, LED_1_Red);
    GPIO_ResetBits(GPIOA, LED_1_Blue);
    GPIO_SetBits(GPIOA, LED_1_Green);
}

void Box1_Red(void)
{
    GPIO_ResetBits(GPIOA, LED_1_Green);
    GPIO_ResetBits(GPIOA, LED_1_Blue);
    GPIO_SetBits(GPIOA, LED_1_Red);
}

void Box1_Blue(void)
{
    GPIO_ResetBits(GPIOA, LED_1_Green);
    GPIO_ResetBits(GPIOA, LED_1_Red);
    GPIO_SetBits(GPIOA, LED_1_Blue);
}

void Box2_Green(void)
{
    GPIO_ResetBits(GPIOA, LED_2_Red);
    GPIO_ResetBits(GPIOA, LED_2_Blue);
    GPIO_SetBits(GPIOA, LED_2_Green);
}

void Box2_Red(void)
{
    GPIO_ResetBits(GPIOA, LED_2_Green);
    GPIO_ResetBits(GPIOA, LED_2_Blue);
    GPIO_SetBits(GPIOA, LED_2_Red);
}

void Box2_Blue(void)
{
    GPIO_ResetBits(GPIOA, LED_2_Green);
    GPIO_ResetBits(GPIOA, LED_2_Red);
    GPIO_SetBits(GPIOA, LED_2_Blue);
}

void Box3_Green(void)
{
    GPIO_ResetBits(GPIOA, LED_3_Red);
    GPIO_ResetBits(GPIOA, LED_3_Blue);
    GPIO_SetBits(GPIOA, LED_3_Green);
}

void Box3_Red(void)
{
    GPIO_ResetBits(GPIOA, LED_3_Green);
    GPIO_ResetBits(GPIOA, LED_3_Blue);
    GPIO_SetBits(GPIOA, LED_3_Red);
}

void Box3_Blue(void)
{
    GPIO_ResetBits(GPIOA, LED_3_Green);
    GPIO_ResetBits(GPIOA, LED_3_Red);
    GPIO_SetBits(GPIOA, LED_3_Blue);
}

