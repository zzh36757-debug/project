#ifndef	__LED_H
#define	__LED_H

#include "stm32f10x.h"                  // Device header

#define LED_GPIO_PROT		GPIOC
#define LED_GPIO_PIN	    GPIO_Pin_13
#define LED_1_Green				GPIO_Pin_1
#define LED_1_Blue   			GPIO_Pin_2
#define LED_1_Red   			GPIO_Pin_0

#define LED_2_Green				GPIO_Pin_4
#define LED_2_Blue   			GPIO_Pin_5
#define LED_2_Red   			GPIO_Pin_3

#define LED_3_Green				GPIO_Pin_7
#define LED_3_Blue   			GPIO_Pin_8
#define LED_3_Red   			GPIO_Pin_6

void LED_Init(void);
void LED_Toggle(void);
void LED_On(void);
void LED_Off(void);
void LED_Twinkle(void);

void Box1_Green(void);
void Box1_Red(void);
void Box1_Blue(void);
void Box2_Green(void);
void Box2_Red(void);
void Box2_Blue(void);
void Box3_Green(void);
void Box3_Red(void);
void Box3_Blue(void);
#endif
