#ifndef __LIGHT_SENSOR_H
#define __LIGHT_SENSOR_H

void LightSensor_Init(void);
uint8_t LightSensor1_Get(void);
uint8_t LightSensor2_Get(void);
uint8_t LightSensor3_Get(void);


#endif
