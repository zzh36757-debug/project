#include "stm32f10x.h"
#include "led.h"
#include "Serial.h"
#include "delay.h"
#include "dht11.h"
#include "oled.h"
#include "Buzzer.h"
#include "LightSensor.h"


/*****************���絥Ƭ�����******************
											STM32
 * �ļ�			:	DHT11�¶�ʪ�ȴ�����ʵ��                    
 * �汾			: V1.0
 * ����			: 2024.8.4
 * MCU			:	STM32F103C8T6
 * �ӿ�			:	��dht11.h�ļ�		
 * IP�˺�		:	���絥Ƭ����ƣ�ͬBILIBILI|����|����|С����|CSDN|���ں�|��Ƶ�ŵȣ�
 * ����			:	����
 * ������		: �췽�����ӹ�����
 * ������Ƶ	:	https://www.bilibili.com/video/BV182421Z7by/?share_source=copy_web&vd_source=097fdeaf6b6ecfed8a9ff7119c32faf2
 * �ٷ���վ	:	www.yfcdz.cn

**********************BEGIN***********************/		

u8 temp;
u8 humi;
int drink1 = -1;
int drink1_Last = 0;
int drink2 = -1;
int drink2_Last = 0;
int drink3 = -1;
int drink3_Last = 0;
u8 Light_Last1 = 0;
u8 Light_Last2 = 0;
u8 Light_Last3 = 0;



int main(void)
{ 
	/*led配置不用理会    		GPIO_SetBits(GPIOA, GPIO_Pin_0);这个是led亮*/
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA,ENABLE);
	GPIO_InitTypeDef GPIO_InitStructure;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP ;
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_0| GPIO_Pin_1|GPIO_Pin_2|GPIO_Pin_3|GPIO_Pin_4|GPIO_Pin_5|GPIO_Pin_6|GPIO_Pin_7|GPIO_Pin_8;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz ;
	GPIO_Init(GPIOA,&GPIO_InitStructure);
	
	
    SystemInit();//����ϵͳʱ��Ϊ72M	
	delay_init(72);
	LED_Init();
	LED_On();
	LightSensor_Init();		//光敏传感器初始化
	/*模块初始化*/
	Buzzer_Init();			//蜂鸣器初始化
	Serial_Init();		
	OLED_Init();
	
	//printf("Start \n");
	delay_ms(1000);
	while(DHT11_Init())
	{
		//printf("DHT11 Error \r\n");
		delay_ms(1000);
	}
	
	Box1_Green();
	Box2_Green();
	Box3_Green();

	//��ʾ���¶ȣ���
	OLED_ShowChinese(0,0,0,16,1); //��
	OLED_ShowChinese(16,0,1,16,1);//��
	OLED_ShowChar(72,0,':',16,1);
	OLED_ShowChar(72, 0, 'C',16,1);	
	//��ʾ��ʪ�ȣ���
	OLED_ShowChinese(0,16,2,16,1); //ʪ
	OLED_ShowChinese(16,16,1,16,1);//��
	OLED_ShowChar(72,16,':',16,1);
	OLED_ShowChar(72, 16, '%',16,1);	
	
	
	
	
  while (1)
  {
		u8 light_now1;
		u8 light_now2;
		u8 light_now3;
		DHT11_Read_Data(&temp,&humi);//
		LED_Toggle();
		delay_ms(1000);
		//��ʾ�¶�����
		OLED_ShowNum(48,0,temp,2,16,1);
		//��ʾʪ������
		OLED_ShowNum(48,16,humi,2,16,1);
	  
		light_now1 = LightSensor1_Get();
		light_now2 = LightSensor2_Get();
		light_now3 = LightSensor3_Get();

		if (light_now1 == 1 && Light_Last1 == 0)
		{
			delay_ms(20);   // ??
			if (LightSensor1_Get() == 1)
			{
				drink1++;				
			}
		}
		if (light_now2 == 1 && Light_Last2 == 0)
		{
			delay_ms(20);   // ??
			if (LightSensor2_Get() == 1)
			{
				drink2++;				
			}
		}
		if (light_now3 == 1 && Light_Last3 == 0)
		{
			delay_ms(20);   // ??
			if (LightSensor3_Get() == 1)
			{
				drink3++;				
			}
		}
		Light_Last1 = LightSensor1_Get();
		Light_Last2 = LightSensor2_Get();
		Light_Last3 = LightSensor3_Get();


		Serial_TxPacket[1] = drink1 +drink2+drink3;
		Serial_TxPacket[2] = temp;
		Serial_TxPacket[3] = humi;

                                                                                                        
		if(drink1 > drink1_Last)
		{
				Box1_Blue();
				Buzzer_OFF();
				Serial_TxPacket[0] = 9;
		}
				if(drink2 > drink2_Last)
		{
				Box2_Blue();
				Buzzer_OFF();
				Serial_TxPacket[0] = 9;
		}
				if(drink3 > drink3_Last)
		{
				Box3_Blue();
				Buzzer_OFF();
				Serial_TxPacket[0] = 9;
		}
	  	else if (Serial_GetRxFlag() == 1)	//如果接收到数据包
		{
			 if(Serial_RxPacket[1] == 1)
			 {
				Box1_Red();
				Buzzer_ON();
			 }
			 else if(Serial_RxPacket[1] == 2)
			 {
				Box2_Red();
				Buzzer_ON();
			 }
			 else if(Serial_RxPacket[1] == 3)
			 {
				Box3_Red();
				Buzzer_ON();
			 }
		}
		OLED_ShowNum(16,32,drink1,2,16,1);
		OLED_ShowNum(48,32,drink2,2,16,1);
		OLED_ShowNum(72,32,drink3,2,16,1);  

		drink1_Last = drink1;
		drink2_Last = drink2;
		drink3_Last = drink3;

		Serial_SendPacket();		//???????Serial_TxPacket
		
  }
}



