#define BLINKER_WIFI
#include <Blinker.h>
#include <time.h>

char auth[] = "20f36a3976ca";
char ssid[] = "esp8266";
char pswd[] = "88888888";

BlinkerButton Button1("w");
BlinkerNumber wd("wd");
BlinkerNumber sd("sd");
BlinkerNumber hourNum("hour");
BlinkerNumber minNum("min");
BlinkerNumber drink("drink");

BlinkerText timeShow1("time1");
BlinkerText timeShow2("time2");
BlinkerText timeShow3("time3");

int Serial_RxPacket[6];
int RxData = 0;
int wendu = 0;
int shidu = 0;
int fuyao = 0;
int first = 0;

// 3组服药时间
int medicineHour1 = 8;
int medicineMinute1 = 30;

int medicineHour2 = 12;
int medicineMinute2 = 0;

int medicineHour3 = 20;
int medicineMinute3 = 0;

// 防止同一分钟重复触发
int lastTriggerKey = -1;

void button1_callback(const String & state)
{
    digitalWrite(LED_BUILTIN, !digitalRead(LED_BUILTIN));
}

void sendTimeToSTM32(int order1, int order2)
{
    uint8_t txPacket[6];
    txPacket[0] = 0xFF;
    txPacket[1] = order1;
    txPacket[2] = order2;
    txPacket[3] = 0x00;
    txPacket[4] = 0x00;
    txPacket[5] = 0xFE;

    Serial.write(txPacket, 6);
}

// 输入格式示例：
// 1:08:30   -> 设置第1个时间
// 2:12:00   -> 设置第2个时间
// 3:20:15   -> 设置第3个时间
void dataRead(const String & data)
{
    //BLINKER_LOG("收到数据: ", data);

    int firstColon = data.indexOf(':');
    int secondColon = data.indexOf(':', firstColon + 1);

    if (firstColon > 0 && secondColon > firstColon)
    {
        String indexStr = data.substring(0, firstColon);
        String hourStr = data.substring(firstColon + 1, secondColon);
        String minuteStr = data.substring(secondColon + 1);

        int index = indexStr.toInt();
        int tempHour = hourStr.toInt();
        int tempMinute = minuteStr.toInt();

        // 简单合法性判断
        if (tempHour < 0 || tempHour > 23 || tempMinute < 0 || tempMinute > 59)
        {
            BLINKER_LOG("时间格式错误");
            return;
        }

        String showStr = "";
        if (tempHour < 10) showStr += "0";
        showStr += String(tempHour);
        showStr += ":";
        if (tempMinute < 10) showStr += "0";
        showStr += String(tempMinute);

        if (index == 1)
        {
            medicineHour1 = tempHour;
            medicineMinute1 = tempMinute;
            timeShow1.print(showStr);
            //BLINKER_LOG("设置第1个服药时间: ", showStr);
        }
        else if (index == 2)
        {
            medicineHour2 = tempHour;
            medicineMinute2 = tempMinute;
            timeShow2.print(showStr);
            //BLINKER_LOG("设置第2个服药时间: ", showStr);
        }
        else if (index == 3)
        {
            medicineHour3 = tempHour;
            medicineMinute3 = tempMinute;
            timeShow3.print(showStr);
            //BLINKER_LOG("设置第3个服药时间: ", showStr);
        }
    }
}

void setup() {
    Serial.begin(9600);

    pinMode(LED_BUILTIN, OUTPUT);
    digitalWrite(LED_BUILTIN, HIGH);

    Blinker.begin(auth, ssid, pswd);
    Blinker.attachData(dataRead);
    Button1.attach(button1_callback);

    configTime(8 * 3600, 0, "ntp1.aliyun.com", "ntp.ntsc.ac.cn", "pool.ntp.org");

    time_t now = time(nullptr);
    while (now < 100000) {
        delay(500);
        now = time(nullptr);
    }

    // 上电后先显示默认值
    timeShow1.print("08:30");
    timeShow2.print("12:00");
    timeShow3.print("20:00");
}

void loop() {
    static int RxState = 0;
    static int pRxPacket = 0;
    static unsigned long lastUiUpdate = 0;

    Blinker.run();

    if (Serial.available() > 0)
    {
        RxData = Serial.read();

        if (RxState == 0)
        {
            if (RxData == 0xFF)
            {
                RxState = 1;
                pRxPacket = 0;
            }
        }
        else if (RxState == 1)
        {
            Serial_RxPacket[pRxPacket] = RxData;
            pRxPacket++;

            if (pRxPacket >= 5)
            {
                RxState = 0;
                if (Serial_RxPacket[4] == 0xFE)
                {   
                    first = Serial_RxPacket[0];
                    fuyao = Serial_RxPacket[1];
                    wendu = Serial_RxPacket[2];
                    shidu = Serial_RxPacket[3];
                }
            }
        }
    }

    time_t now = time(nullptr);
    struct tm *p = localtime(&now);

    int nowHour = p->tm_hour;
    int nowMinute = p->tm_min;

    int nowKey = nowHour * 100 + nowMinute;
    int setKey1 = medicineHour1 * 100 + medicineMinute1;
    int setKey2 = medicineHour2 * 100 + medicineMinute2;
    int setKey3 = medicineHour3 * 100 + medicineMinute3;

    if (first == 0)
    {
        if (nowKey == setKey1 && lastTriggerKey != nowKey)
        {
            sendTimeToSTM32(1, 1);
            lastTriggerKey = nowKey;
        }
        else if (nowKey == setKey2 && lastTriggerKey != nowKey)
        {
            sendTimeToSTM32(1, 2);
            lastTriggerKey = nowKey;
        }
        else if (nowKey == setKey3 && lastTriggerKey != nowKey)
        {
            sendTimeToSTM32(1, 3);
            lastTriggerKey = nowKey;
        }
    }

    if (nowKey != setKey1 && nowKey != setKey2 && nowKey != setKey3)
    {
        lastTriggerKey = -1;
    }

    // 每500ms更新一次App显示，别每圈都发
    if (millis() - lastUiUpdate >= 500)
    {
        lastUiUpdate = millis();

        drink.print(fuyao);
        wd.print(wendu);
        sd.print(shidu);
        hourNum.print(nowHour);
        minNum.print(nowMinute);
    }
}